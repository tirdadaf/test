package com.tirdad.tirbargh;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.view.View.LAYOUT_DIRECTION_RTL;

public class ads extends AppCompatActivity {

    public String url_ads;
    public int Current_page = 0;
    private List<HashMap<String, Object>> all_ads = new ArrayList();
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ads);
        setTitle("آگهی ها");
        getWindow().getDecorView().setLayoutDirection(LAYOUT_DIRECTION_RTL);

        clear_cache();

        lv = (ListView) findViewById(R.id.ads_list);

        Bundle address = getIntent().getExtras();

        if (address.getString("flag")==null)
        {
            url_ads = address.getString("url");

            make_all_ads_list();

        }
        else
        {
            Toast.makeText(getApplicationContext(),
                    "On lv_cat",Toast.LENGTH_SHORT).show();

            url_ads = address.getString("url_by_cat");

            make_ads_list_by_cat();
        }



        lv.setOnScrollListener(new AbsListView.OnScrollListener()
        {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
                if (view.getId() == lv.getId())
                {
                    int currentFirstVisibleItem = lv.getFirstVisiblePosition();
                    int mlastFirstVisibleItem = lv.getLastVisiblePosition();
                    if (currentFirstVisibleItem > mlastFirstVisibleItem)
                    {
                        //go up
                    }
                    else if (currentFirstVisibleItem < mlastFirstVisibleItem)
                    {
                //        //go downn
                        make_all_ads_list();
                    }
                    mlastFirstVisibleItem = currentFirstVisibleItem;
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
            {

            }
        });

        lv.setOnItemClickListener(
                new AdapterView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view
                            , int position, long id)
                    {
                        Toast.makeText(getApplicationContext(),
                                "On Click CLICK",Toast.LENGTH_SHORT).show();
                        Intent
                                Intent = new Intent(getApplicationContext(),show_full_ads.class);

                        Intent.putExtra("ads",all_ads.get( position));

                        startActivity(Intent);

                    }
                }
        );

    }



    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        clear_cache();
    }

    public void make_all_ads_list() {
        try {

            DownloadTask dl = new DownloadTask();

            dl.execute(url_ads + Current_page);

            Current_page++;


        } catch (Exception e) {

            Log.i("Mati Message", "Error in CatParser in make_ads_list -> " + e.toString());

        }

    }

    public void make_ads_list_by_cat() {
        try {

            DownloadTask dl = new DownloadTask();

            dl.execute(url_ads + Current_page);

            Current_page++;


        } catch (Exception e) {

            Log.i("Mati Message", "Error in CatParser in  make_ads_list_by_cat -> " + e.toString());

        }

    }

    private class DownloadTask extends AsyncTask<String, Void, String>

    {

        @Override

        protected String doInBackground(String... params) {
            String temp = "";

            try {

                JSONdownloader jd = new JSONdownloader();

                temp = jd.downloadURL(params[0]);

            } catch (Exception e) {

                Log.i("Mati Message", "Error in CatParser in doInBackground -> " + e.toString());

            }
            return (temp);
        }

        @Override
        protected void onPostExecute(String s) {
            ListViewloadertask loader = new ListViewloadertask();
            loader.execute(s);
        }

        private class ListViewloadertask extends AsyncTask<String, Void, SimpleAdapter> {

            @Override
            protected SimpleAdapter doInBackground(String... params) {
                try {

                    adsparser parser = new adsparser();

                    all_ads.addAll(parser.parse(params[0]));

                } catch (Exception e) {
                    Log.i("Mati Message", "Error in CatParser in doInBackground ListViewloadertask-> " +
                            e.toString());
                }

                String[] from = {"image", "title", "intro", "date", "cat"};
                int[] to = {R.id.ads_img, R.id.ads_title, R.id.ads_intro, R.id.ads_date, R.id.ads_cat};
                SimpleAdapter adb = new SimpleAdapter(
                        getBaseContext(), all_ads, R.layout.ads_list_row, from, to);


                return adb;
            }

            @Override
            protected void onPostExecute(SimpleAdapter simpleAdapter) {
                lv.setAdapter(simpleAdapter);

                for (int i = 0; i < simpleAdapter.getCount(); i++) {
                    HashMap<String, Object> hm = (HashMap<String, Object>) simpleAdapter.getItem(i);

                    String imgURL = (String) hm.get("image_path");

                    HashMap<String, Object> forDownload = new  HashMap();

                    forDownload.put("image_path",imgURL);
                    forDownload.put("position",i);

                    ImageDownloaderTask imgDownloader = new ImageDownloaderTask();

                    imgDownloader.execute(forDownload);

                }
            }
        }

        private class ImageDownloaderTask extends
                AsyncTask<HashMap<String, Object>, Void, HashMap<String, Object>>
        {
            @Override
            protected HashMap<String, Object> doInBackground(HashMap<String, Object>... params)
            {
                InputStream mystream;

                String imgUrl   = (String)  params[0].get("image_path");
                imgUrl = imgUrl.replaceFirst("localhost","192.168.0.104");
                int    position = (Integer) params[0].get("position");

                try
                {
                    URL url = new URL(imgUrl);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                    connection.setReadTimeout( 100000);

                    connection.setConnectTimeout(15000);

                    connection.setDoInput(true);

                    mystream = connection.getInputStream();

                    File cachedirectory = getBaseContext().getCacheDir();

                    File temp = new File(cachedirectory.getPath()+
                                    "/image_"+position+"_"+Current_page+".png");

                    FileOutputStream outstream = new FileOutputStream(temp);

                    Bitmap b = BitmapFactory.decodeStream( mystream );

                    b.compress(Bitmap.CompressFormat.PNG,100,outstream);

                    outstream.flush();

                    outstream.close();

                    HashMap<String,Object> bitmap = new HashMap<>();

                    bitmap.put("image",temp.getPath());

                    bitmap.put("position",position);

                    return (bitmap);
                }
                catch (Exception e)
                {
                    Log.i("Mati Message", "Error in CatParser in" +
                            " doInBackground ImageDownloaderTask-> " +imgUrl.toString()+
                            e.toString());
                }

                return null;
            }
            @Override
            protected void onPostExecute(HashMap<String, Object> result)
            {
                String image = (String) result.get("image");

                int position = (Integer) result.get("position");

                SimpleAdapter adb = (SimpleAdapter) lv.getAdapter();

                HashMap<String, Object> hm = (HashMap<String, Object>)
                        adb.getItem(position);

                hm.put("image",image);

                adb.notifyDataSetChanged();
            }

        }
    }
    public void clear_cache()
    {
        try
        {
            File f[] = getBaseContext().getCacheDir().listFiles();

            for (File file : f)
            {

                file.delete();
            }
        }
        catch (Exception e)
        {
            Log.i("Mati Message", "Error in clear cach" +
                    e.toString());
        }
    }

}

