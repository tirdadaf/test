package com.tirdad.tirbargh;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;

import static android.view.View.LAYOUT_DIRECTION_RTL;

public class welcome extends AppCompatActivity {

    private final String url_cat = "http://192.168.0.104/irprogram/get_cat.php";
    private final String url_ads = "http://192.168.0.104/irprogram/get_data.php?page=";
    private final String url_ads_by_cat = "http://192.168.0.104/irprogram/get_data_by_cat.php?cat=";
    private final String url_insert_ads = "http://192.168.0.104/irprogram/set_data.php";
    private List<HashMap<String,Object>> all_cat;
    private ListView lv_cat;

    public boolean isConnected()
    {
        ConnectivityManager cm = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] ni = cm.getAllNetworkInfo();
        for (int i = 0; i < ni.length; i++) {
            if (ni[i].getState() == NetworkInfo.State.CONNECTED) {
                return true;
            }
        }
        return false;
    }
    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        if  (isConnected() == false)
        {
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setCancelable(true);
            alert.setTitle(R.string.internet_error_title);
            alert.setMessage(R.string.internet_error_message);
            alert.setPositiveButton(R.string.btn_exit,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            System.exit(0);
                        }
                    });
            alert.create();
            alert.show();

        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        getWindow().getDecorView().setLayoutDirection(LAYOUT_DIRECTION_RTL);
        navigation_drawer nd = (navigation_drawer)
                getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        nd.setup( (DrawerLayout) findViewById(R.id.welcome_layout) );

        lv_cat = (ListView) findViewById(R.id.catagory_list);

        make_catagory_list();

        Toast.makeText(getApplicationContext(),
                "before lv_cat",Toast.LENGTH_SHORT).show();

        lv_cat.setOnItemClickListener(

                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id)
                    {
                        try
                        {
                            Intent j = new Intent(getApplicationContext(), ads.class);
                            j.putExtra("url_by_cat"
                                    , url_ads_by_cat + all_cat.get(position).get("id").toString());

                            j.putExtra("flag", "1");

                            startActivity(j);
                        }
                        catch (Exception e)
                        {
                            Log.i("Mati Message", "Error in lv_cat -> " + e.toString());

                        }

                    }
                }
        );


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_welcome, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
        {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.action_settings),Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onbtnshowadsclick( View v )
    {
        Intent intent = new Intent( this,ads.class);
        intent.putExtra("url",url_ads);

        String[] id = new String[all_cat.size()];
        String[] name = new String[all_cat.size()];

        for  (int i = 0 ; i < all_cat.size() ; i++)
        {
              id[i] = all_cat.get( i ).get("id").toString();
              name [i] = all_cat.get(i).get("name").toString();

        }
        intent.putExtra("cat_id",id);
        intent.putExtra("cat_name",name);

        startActivity(intent);
    }

    public void onbtninsertadsclick( View v )

    {
        Intent intent = new Intent( this,insert_ads.class);
        intent.putExtra("url",url_insert_ads);

        String[] id = new String[all_cat.size()];
        String[] name = new String[all_cat.size()];

        for  (int i = 0 ; i < all_cat.size() ; i++)
        {
            id[i] = all_cat.get( i ).get("id").toString();
            name [i] = all_cat.get(i).get("name").toString();

        }
        intent.putExtra("cat_id",id);
        intent.putExtra("cat_name",name);

        startActivity(intent);
    }

    public void onbtnexitclik( View v )
    {
       finish();
    }

    private  class DownloadCats extends AsyncTask<String , Void, String>
    {
        @Override
        protected String doInBackground(String... params)
        {
            String data = "";

            JSONdownloader jd = new JSONdownloader();

            data = jd.downloadURL( params [0]);



            return data;
        }
        @Override
        protected void onPostExecute(String json)
        {
            CatParser Parser = new CatParser();
            all_cat = Parser.parse( json );

            String [] from = {"name","amount"};
            int    [] to   = {R.id.name_cat,R.id.amount_cat};

            SimpleAdapter myAdaptor = new SimpleAdapter(
                    getBaseContext(),all_cat,R.layout.cat_list_row,from,to);
            lv_cat.setAdapter(myAdaptor);
        }


    }


    public void make_catagory_list()
    {
        DownloadCats dl_cat = new DownloadCats();

        dl_cat.execute(url_cat);
    }
    public void onbtnaboutmeclick( View v )
    {

    }
}
