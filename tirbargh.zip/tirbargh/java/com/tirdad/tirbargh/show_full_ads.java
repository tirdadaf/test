package com.tirdad.tirbargh;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.HashMap;


public class show_full_ads extends AppCompatActivity

{
    private  ImageView ads_img;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_full_ads);
        setTitle("اطلاعات آگهی");
        

        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Bundle data = getIntent().getExtras();
        HashMap<String,Object> hm =
                (HashMap<String,Object>) data.get("ads");

        boolean flag = false;

        String temp = (String) (hm.get("image").toString());


        try {
             double t = Double.parseDouble(temp);
             flag = true;
            }
        catch (Exception e)
        {
          flag = false;
        }

        ads_img = (ImageView) findViewById(R.id.full_ads_image);
        TextView  ads_title = (TextView) findViewById(R.id.full_ads_title);
        TextView  ads_intro = (TextView) findViewById(R.id.full_ads_intro);
        TextView  ads_desc = (TextView) findViewById(R.id.full_ads_desc);
        TextView  ads_seller = (TextView) findViewById(R.id.full_ads_seller);
        TextView  ads_email = (TextView) findViewById(R.id.full_ads_email);
        TextView  ads_phone = (TextView) findViewById(R.id.full_ads_phone);
        TextView  ads_cat = (TextView) findViewById(R.id.full_ads_cat);
        TextView  ads_date = (TextView) findViewById(R.id.full_ads_date);


        if (flag ==false)
        {
            File imgfile = new File ((String) hm.get("image").toString());
            if (imgfile .exists())
            {
               Bitmap mybitmap = BitmapFactory.decodeFile(imgfile.getPath());
               ads_img.setImageBitmap(mybitmap);
            }
            else
            {
               ads_img.setImageResource(R.drawable.download);
            }
        }
        else
        {
            ads_img.setImageResource(R.drawable.download);
        }

        ads_title.setText( (String) hm.get("title"));
        ads_intro.setText( (String) hm.get("intro"));
        ads_desc.setText( (String) hm.get("desc"));
        ads_date.setText( (String) hm.get("date"));
        ads_email.setText( (String) hm.get("email"));
        ads_phone.setText( (String) hm.get("phone"));
        ads_seller.setText( (String) hm.get("seller"));
        ads_cat.setText( (String) hm.get("cat"));


    }

    public void LoadImageFullScreen (View v)
    {
        AlertDialog.Builder imageLoader = new AlertDialog.Builder( this);

        LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);

        View layout = inflater.inflate(R.layout.full_screen_image,
                (ViewGroup) findViewById(R.id.full_img_layout_root));

        ImageView bigImage = (ImageView) layout.findViewById(R.id.full_img_img);

        bigImage.setImageDrawable(ads_img.getDrawable());

        TextView imgTitle = (TextView) layout.findViewById(R.id.full_img_title);

        imgTitle.setText(R.string.big_image_title);

        imageLoader.setView(layout);

        imageLoader.setCancelable(true);

        imageLoader.setPositiveButton(R.string.btn_back_to_home,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }
        );
        imageLoader.setNegativeButton(R.string.btn_back_to_home,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        imageLoader.setNeutralButton(R.string.btn_back_to_home,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        imageLoader.create();

        imageLoader.show();

    }

}
