package com.tirdad.tirbargh;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class JSONdownloader
{

    private static String Log_Label = "MatiMessage";

    public static String downloadURL( String strUrl)
    {
        String Data = "";

        InputStream myStream;

        try
        {
            URL url = new URL( strUrl);

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setReadTimeout( 100000);

            connection.setConnectTimeout(15000);

            connection.setRequestMethod( "GET" );

            connection.setDoInput(true);

            connection.connect();

            myStream = connection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(myStream));

            StringBuilder sb = new StringBuilder();

            String line;

            while ( ( line = br.readLine()) != null)
            {
                sb.append(line);
            }

            Data = sb.toString();

            br.close();

            connection.disconnect();

            myStream.close();



        }
        catch ( Exception e )
        {
          Log.i( Log_Label , "Error in JSONdownloader in downloadURL -> " + e.toString() );
        }
        return Data;
    }

    
}
