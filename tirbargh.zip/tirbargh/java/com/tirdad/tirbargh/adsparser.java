package com.tirdad.tirbargh;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class adsparser
{
     public List<HashMap<String , Object>> parse (String json)
     {
         List<HashMap<String,Object>> all_ads = new ArrayList<>();

         JSONObject jObj;



         try
         {

              jObj = new JSONObject( json );

             JSONArray jArr = jObj.getJSONArray("ads");

             for ( int i = 0 ; i < jArr.length() ; i ++)
             {
                 HashMap< String , Object> ads = new HashMap<String , Object>();

                 JSONObject temp = (JSONObject)  jArr.get( i );

                 ads.put("id",temp.getString( "id"));
                 ads.put("title",temp.getString( "title"));
                 ads.put("intro",temp.getString( "intro"));
                 ads.put("desc",temp.getString( "desc"));
                 ads.put("image",R.drawable.download);
                 ads.put("image_path",temp.getString( "image"));
                 ads.put("seller",temp.getString( "seller"));
                 ads.put("email",temp.getString( "email"));
                 ads.put("phone",temp.getString( "phone"));
                 ads.put("date",temp.getString( "date"));
                 ads.put("cat",temp.getString( "cat"));
                 all_ads.add(ads);

             }

         }

         catch (Exception  e)
         {
             Log.i( "Mati Message" , "Error in adsParser in parser -> " + e.toString() );
         }

         return ( all_ads);
     }

}
