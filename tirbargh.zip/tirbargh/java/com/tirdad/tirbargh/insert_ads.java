package com.tirdad.tirbargh;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

import static android.view.View.LAYOUT_DIRECTION_RTL;

public class insert_ads extends AppCompatActivity
{

    private String url_insert_ads;
    private String[] id;
    private String[] name;
    private ListView lv_cat;

    private EditText title,intro,desc,seller,email,phone;
    private TextView selected_cat,selected_img_txt;
    private ImageView selected_img;
    private  String [] selected_cat_info = new String[2];

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_ads);
        getWindow().getDecorView().setLayoutDirection(LAYOUT_DIRECTION_RTL);
        /*-----------------------------------------*/
          selected_cat = (TextView) findViewById(R.id.txt_insert_ads_selected_cat);
          selected_img_txt = (TextView) findViewById(R.id.insert_ads_selected_img_txt);
          selected_img = (ImageView) findViewById(R.id.insert_ads_selected_img);
          title        = (EditText) findViewById(R.id.insert_ads_title);
          intro        = (EditText) findViewById(R.id.insert_ads_intro);
          seller       = (EditText) findViewById(R.id.insert_ads_seller);
          email        = (EditText) findViewById(R.id.insert_ads_email);
          desc         = (EditText) findViewById(R.id.insert_ads_desc);
          phone        = (EditText) findViewById(R.id.insert_ads_phone);


        /*------------------------------------------*/

        Bundle data = getIntent().getExtras();
        url_insert_ads = data.getString("url");

        id = data.getStringArray("cat_id");
        name = data.getStringArray("cat_name");

        ArrayList<String> cats = new ArrayList<>();
        for (int i = 0; i < id.length; i++) {
            cats.add(i, name[i]);
        }
        ArrayAdapter<String> adb = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, cats);
        lv_cat = (ListView) findViewById(R.id.insert_ads_cat_list);
        lv_cat.setAdapter(adb);
        lv_cat.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent,View view, int position, long _id)
                    {
                        selected_cat_info [0] = id [ position ];
                        selected_cat_info [1] = name [position];

                        selected_cat.setText( name [position]);

                    }
                }
        );
    }

    private int my_requestcode = 1;
    private Bitmap my_bitmap;
    private String my_final_image;

    public void onBtnCameraClick (View v)

    {
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY))
        {
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            startActivityForResult(i,my_requestcode);
        }
        else
        {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.no_camera_error),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == my_requestcode && resultCode == RESULT_OK)
        {
           Bundle e = data.getExtras();
           my_bitmap = (Bitmap) e.get("data");
           show_captured_image();
        }
        else if (requestCode == my_requestcode_gallery && resultCode == RESULT_OK)
        {
            Uri image = data.getData();

            show_internal_image( image );
        }
        else
        {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.get_image_from_camera_error),
                    Toast.LENGTH_LONG).show();
        }

    }
    public  void show_captured_image()
    {
      try {


          AlertDialog.Builder imageLoader = new AlertDialog.Builder(this);

          LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);

          View layout = inflater.inflate(R.layout.full_screen_image,
                  (ViewGroup) findViewById(R.id.full_img_layout_root));

          ImageView bigImage = (ImageView) layout.findViewById(R.id.full_img_img);

          bigImage.setImageBitmap(my_bitmap);

          TextView imgTitle = (TextView) layout.findViewById(R.id.full_img_title);

          imgTitle.setText(R.string.big_image_title);

          imageLoader.setView(layout);

          imageLoader.setCancelable(true);

          imageLoader.setPositiveButton(R.string.captured_img_btn_ok,
                  new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          //ByteArrayOutputStream mystream = new ByteArrayOutputStream();
                          //my_bitmap.compress(Bitmap.CompressFormat.JPEG, 90, mystream);
                          //byte[] bytearray = mystream.toByteArray();
                          //my_final_image = Base64.encodeToString(bytearray, 0);
                          selected_img.setImageBitmap(my_bitmap);
                          selected_img_txt.setText(R.string.captured_img_btn_ok);
                          dialog.dismiss();
                      }
                  }
          ).setNegativeButton(R.string.captured_img_btn_again,
                  new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          dialog.dismiss();
                          onBtnCameraClick(null);
                      }
                  });
          imageLoader.setNeutralButton(R.string.btn_back_to_home,
                  new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          dialog.dismiss();
                      }
                  });

          imageLoader.create();

          imageLoader.show();
      }
        catch (Exception e)
        {
            Log.i( "Mati Message" , "Error in adsParser in parser -> " + e.toString() );
        }
    }

    public void show_internal_image (final Uri imageUri)

    {
        try {

            AlertDialog.Builder imageLoader = new AlertDialog.Builder(this);

            LayoutInflater inflater = (LayoutInflater)
                    this.getSystemService(LAYOUT_INFLATER_SERVICE);

            View layout = inflater.inflate(R.layout.full_screen_image,
                    (ViewGroup) findViewById(R.id.full_img_layout_root));

            ImageView bigImage = (ImageView) layout.findViewById(R.id.full_img_img);

            bigImage.setImageURI(imageUri);

            TextView imgTitle = (TextView) layout.findViewById(R.id.full_img_title);

            imgTitle.setText(R.string.big_image_title);

            imageLoader.setView(layout);

            imageLoader.setCancelable(true);

            imageLoader.setPositiveButton(R.string.captured_img_btn_ok,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //InputStream stream = null;
                            //try{
                            //    stream = getContentResolver().openInputStream(imageUri);
                            //}
                            //catch (Exception e)
                            //{
                            //    Log.i( "Mati Message" , "Error in Gallery -> " + e.toString() );
                            //}
                            //my_bitmap = BitmapFactory.decodeStream(stream);
                            //ByteArrayOutputStream mystream = new ByteArrayOutputStream();
                            //my_bitmap.compress(Bitmap.CompressFormat.JPEG, 90, mystream);
                            //byte[] bytearray = mystream.toByteArray();
                            //my_final_image = Base64.encodeToString(bytearray, 0);
                            selected_img.setImageURI(imageUri);
                            selected_img_txt.setText(R.string.captured_img_btn_ok);
                            dialog.dismiss();
                        }
                    }
            ).setNegativeButton(R.string.captured_img_btn_again,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            onBtnGalleryClick(null);
                        }
                    });
            imageLoader.setNeutralButton(R.string.btn_back_to_home,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

            imageLoader.create();

            imageLoader.show();
        }
        catch (Exception e)
        {
            Log.i( "Mati Message" , "Error in adsParser in parser -> " + e.toString() );
        }
    }




    private int my_requestcode_gallery = 2;
    public void  onBtnGalleryClick (View v)
    {
        Intent i = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.INTERNAL_CONTENT_URI);

        startActivityForResult(i,my_requestcode_gallery);
    }

    public void onBtninsertAdsClick(View v)
    {
        if (title.getText().length() > 1)
        {
            if (intro.getText().length() > 1)
            {
                if (desc.getText().length() > 1)
                {
                    if (seller.getText().length() > 1)
                    {
                        if (email.getText().length() > 1)
                        {
                            if (phone.getText().length() > 1)
                            {
                                if (selected_cat.getText()
                                        != getString(R.string.insert_ads_form_sel_cat_text))
                                    if (selected_img_txt.getText()
                                            != getString(R.string.insert_ads_form_sel_cat_text)) {

                                        Bitmap image = ((BitmapDrawable)
                                                selected_img.getDrawable()).getBitmap();
                                        HashMap<String, String> my_data = new HashMap<>();
                                        my_data.put("title", title.getText().toString());
                                        my_data.put("intro", intro.getText().toString());
                                        my_data.put("desc", desc.getText().toString());
                                        my_data.put("seller", seller.getText().toString());
                                        my_data.put("email", email.getText().toString());
                                        my_data.put("phone", phone.getText().toString());
                                        my_data.put("cat", selected_cat_info[0]);
                                        Log.d( "Mati Message" , "before upload -> "  );
                                        UploadImage upload = new UploadImage(my_data, image,this);
                                        upload.execute();


                                    } else {
                                        Toast.makeText(getApplicationContext(),
                                                getString(R.string.insert_ads_form_error_sel_img),
                                                Toast.LENGTH_LONG).show();
                                    }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),
                                            getString(R.string.insert_ads_form_error_sel_cat),
                                            Toast.LENGTH_LONG).show();
                                }
                            }

                            else
                            {
                                phone.setHint(R.string.insert_ads_form_error_hint);
                            }
                        }
                        else
                        {
                            email.setHint(R.string.insert_ads_form_error_hint);
                        }
                    }
                    else
                    {
                        seller.setHint(R.string.insert_ads_form_error_hint);
                    }
                }
                else
                {
                    desc.setHint(R.string.insert_ads_form_error_hint);
                }
            }
            else
            {
                intro.setHint(R.string.insert_ads_form_error_hint);
            }
        }
        else
        {
            title.setHint(R.string.insert_ads_form_error_hint);
        }
    }
    private class UploadImage extends AsyncTask<Void,Void,Boolean>
    {

        private Context main_con;
        private HashMap<String, String> main_hm;
        private Bitmap main_image;
        public UploadImage(HashMap<String, String> hm, Bitmap image,Context con)
        {
            main_hm = hm;
            main_image = image;
            main_con = con;

        }

        @Override
        protected Boolean doInBackground(Void... params)
        {

            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            main_image.compress(Bitmap.CompressFormat.JPEG,100,outStream);
            String encodedImage = Base64.encodeToString(outStream.toByteArray(),Base64.DEFAULT);
            ArrayList<NameValuePair> datatosend = new ArrayList<>();

            datatosend.add(new BasicNameValuePair("title",main_hm.get("title")));
            datatosend.add(new BasicNameValuePair("intro",main_hm.get("intro")));
            datatosend.add(new BasicNameValuePair("desc",main_hm.get("desc")));
            datatosend.add(new BasicNameValuePair("seller",main_hm.get("seller")));
            datatosend.add(new BasicNameValuePair("email",main_hm.get("email")));
            datatosend.add(new BasicNameValuePair("phone",main_hm.get("phone")));
            datatosend.add(new BasicNameValuePair("cat",main_hm.get("cat")));
            datatosend.add(new BasicNameValuePair("image",encodedImage));


            HttpParams myHttpParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(myHttpParams,1000*30);
            HttpConnectionParams.setSoTimeout(myHttpParams,1000*30);
            HttpClient client = new DefaultHttpClient(myHttpParams);

            HttpPost post = new HttpPost(url_insert_ads );

            try {
                post.setEntity( new UrlEncodedFormEntity( datatosend ));

                HttpResponse response = client.execute(post);

                BufferedReader rd = new BufferedReader
                        (new InputStreamReader(
                                response.getEntity().getContent()));
                String line = "";
                String sp   = "";
                while ((line = rd.readLine()) != null) {
                    sp = sp+line;
                }
                Log.d( "Mati Message" , "after execute " + sp);
                return true;
            }
             catch ( Exception e)
             {
                 Log.i( "Mati Message" , "Error in posting data -> " + e.toString() );

                return false;
             }

        }


        @Override
        protected void onPostExecute(Boolean aBoolean)
            {

            String message = null;

            if (aBoolean == true)
            {
                message = getString(R.string.result_of_insert_message_success);
            }
            else
            {
                message = getString(R.string.result_of_insert_message_failure);
            }

            //define from upload class
            AlertDialog.Builder alert = new AlertDialog.Builder(main_con);
            alert.setCancelable(false);
            alert.setTitle("وضعیت");
            alert.setMessage(message);
            alert.setPositiveButton(R.string.btn_back_to_home,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                           dialog.dismiss();
                        }
                    });
            alert.show();
            }
        }



    public void onBtnBackClick (View v)

    {
        finish();
    }
}
